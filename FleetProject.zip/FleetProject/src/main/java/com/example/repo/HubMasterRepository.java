package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.entity.HubMaster;


@Repository
@Transactional
public interface HubMasterRepository extends JpaRepository<HubMaster,Integer>
{
	@Query("SELECT h FROM HubMaster h WHERE h.cityid=:id")
	List<HubMaster> findByCityId(@Param("id") int id);
}
