package com.example.repo;

import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.entity.BookingHeader;


@Repository
@Transactional
public interface BookingHeaderRepository extends JpaRepository<BookingHeader,Integer>
{

	@Modifying
	  @Query("update BookingHeader bh set bh.startdate= :startdate, bh.enddate= :enddate, bh.pickuplocation= :pickuplocation, bh.dropofflocation= :dropofflocation where bh.bookingid = :bookingid")
	    void update(@Param("startdate") Date startdate,
	                        @Param("enddate") Date enddate,
	                        @Param("pickuplocation") String pickuplocation,
	                        @Param("dropofflocation") String dropofflocation,@Param("bookingid") int bookingid);

	@Modifying
	@Query(nativeQuery = true,value ="SELECT cm.image_path AS ImagePath,bk.cartypesi_car_type_id AS CarTypesi ,cm.daily_rate AS DailyRate,"
			+ "c.cardtl AS cardtl,cm.car_type_name AS CarTypeName,c.isavailable AS isavailable,bk.bookingid AS BookingId,"
			+ "cu.driving_licence_no,cu.fname,cu.lname FROM Booking_Header AS bk "
			+ "JOIN car_types AS cm ON bk.cartypesi_car_type_id=cm.car_type_id "
			+ "JOIN carmaster AS c ON cm.car_type_id=c.cartypeid "
			+ "JOIN customers AS cu ON bk.cartypesi_car_type_id=cu.cust_id WHERE bookingid=:id")
	List<Map<String, Object>> findByBookingId(@Param("id") int id);

	
}
