package com.example.dto;

import com.example.entity.Customers;

public class LoginResponse {
    private boolean success;
    private Customers customer;

    public LoginResponse(boolean success, Customers customer) {
        this.success = success;
        this.customer = customer;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Customers getCustomer() {
        return customer;
    }

    public void setCustomer(Customers customer) {
        this.customer = customer;
    }
}
