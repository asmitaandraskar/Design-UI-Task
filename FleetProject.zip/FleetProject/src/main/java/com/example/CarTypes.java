package com.example.demo;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.example.carmaster.CarMaster;

@Entity
@Table(name="CarTypes")
public class CarTypes
{
	private int CarTypeId;
	private String CarTypeName;
	private float DailyRate;
	private float WeeklyRate;
	private float MonthlyRate;
	private String ImagePath;
	private Set<CarMaster> Cars;
public CarTypes()
{
	super();
}


public CarTypes(int CarTypeId,String CarTypeName,float Daily_Rate,
		float Weekly_Rate,float Monthly_Rate,String ImagePath,Set<CarMaster> Cars)
{
super();
this.CarTypeId=CarTypeId;
this.CarTypeName=CarTypeName;
this.DailyRate=Daily_Rate;
this.WeeklyRate=Weekly_Rate;
this.MonthlyRate=Monthly_Rate;
this.ImagePath=ImagePath;
this.Cars=Cars;
}

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
public int getCarTypeId()
{
	return CarTypeId;
}
public void setCarTypeId(int CarTypeId) {
	this.CarTypeId = CarTypeId;
}



public String getCarTypeName() {
	return CarTypeName;
}

public void setCarTypeName(String CarTypeName) {
	this.CarTypeName = CarTypeName;
}

public float getDailyRate() {
	return DailyRate;
}

public void setDailyRate(float DailyRate) {
	this.DailyRate = DailyRate;
}

public float getWeeklyRate() {
	return WeeklyRate;
}

public void setWeeklyRate(float WeeklyRate) {
	this.WeeklyRate = WeeklyRate;
}

public float getMonthlyRate() {
	return MonthlyRate;
}

public void setMonthlyRate(float MonthlyRate) {
	this.MonthlyRate = MonthlyRate;
}

public String getImagePath() {
	return ImagePath;
}

public void setImagePath(String ImagePath) {
	this.ImagePath = ImagePath;
}

@OneToMany(cascade=CascadeType.ALL)
@JoinColumn(name="cid",referencedColumnName="CarTypeId" )
public Set<CarMaster> getCars() {
	return Cars;
}


public void setCars(Set<CarMaster> cars) {
	Cars = cars;
}


@Override
public String toString() {
	return "CarType [CarTypeId=" + CarTypeId + ", CarTypeName=" + CarTypeName + ", DailyRate="
			+ DailyRate + ", WeeklyRate=" + WeeklyRate + ", MonthlyRate=" + MonthlyRate + ", ImagePath="
			+ ImagePath + "]";
}

}

