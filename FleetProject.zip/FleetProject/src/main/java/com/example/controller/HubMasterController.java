package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.HubMaster;
import com.example.service.HubMasterManager;



@RestController
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:8080"}, allowCredentials = "true")
public class HubMasterController 
{
	@Autowired
	@Qualifier("myImplementation")
	HubMasterManager manager;
	
	 @GetMapping(value = "/api/gethubmaster")
	 public List<HubMaster> showHubs() 
	 {
		 System.out.println("inside get");
		  return manager.getHubMaster(); 
	 }
	
	 @GetMapping(value = "/api/gethubs/city/{cityId}")
	 public List<HubMaster> getHubsByCityId(@PathVariable int cityId) {
	        return manager.getHubsByCityId(cityId);
	    }
	 
	 @PostMapping(value = "/api/addhubmaster")
	 public void addHubMaster(@RequestBody HubMaster hub)
	 {
		 System.out.println("addHub called");
			manager.addHubMaster(hub);
	 }
}
