package com.example.service;

import org.springframework.http.ResponseEntity;


import com.example.dto.LoginRequest;
import com.example.dto.LoginResponse;
public interface LoginMasterManager {
	ResponseEntity<LoginResponse> login(LoginRequest request);

}