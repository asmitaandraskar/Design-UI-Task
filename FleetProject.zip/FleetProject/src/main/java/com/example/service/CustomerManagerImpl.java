package com.example.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Customers;
import com.example.repo.CustomerRepo;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

@Service
public class CustomerManagerImpl implements CustomerManager {
	
	@Autowired
	CustomerRepo repository;
	
	
	@Override
	public void addCustomer(Customers u) {
		String password= u.getPassword();
		u.setPassword(sha256(password));
		repository.save(u);
		
	}

	@Override
	public List<Customers> getCustomers() {
		// TODO Auto-generated method stub
		return repository.findAll();	
		
	}

	@Override
	public void delete(int id) {
		repository.deleteById(id);
	}

	
	@Override
	public Optional<Customers> getCustomer(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}
	

	public void update(Customers  cust,int id) {
		// TODO Auto-generated method stub
		System.out.println("inside update method of service layer");
		repository.update(cust.getFname(),
				cust.getLname(),
				cust.getAddress(),
				cust.getEmail(),
				cust.getPhoneNum(),
				cust.getAlternateNum(),
				cust.getState(),
				cust.getCity(),
				cust.getZipCode(),
				cust.getDateOfbirth(),
				cust.getAge(),
				cust.getGender(),
				cust.getAdharCardNum(), 
				cust.getPassportNum(),
				cust.getPassportIssueby(),
				cust.getPassportValidupto(),
				cust.getDrivingLicenceNo(),
				cust.getDrivingLicenceIssueby(),
				cust.getDrivingLicenceValidupto(),
				cust.getUserId(),
				cust.getPassword(),
				id);
	}

	private String sha256(String password)
	{
		try
		{
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] hash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
			StringBuilder hexstring = new StringBuilder();
			for(byte b : hash)
			{
				String hex =Integer.toHexString(0xff & b);
				if(hex.length()==1)
					hexstring.append('0');
				hexstring.append(hex);
			}
			return hexstring.toString();
		}
		catch(NoSuchAlgorithmException e)
		{
			throw new RuntimeException(e);
		}
	}

}

