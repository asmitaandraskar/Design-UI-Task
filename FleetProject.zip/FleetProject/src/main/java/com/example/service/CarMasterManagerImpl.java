package com.example.service;

import java.util.List;
//import java.util.Optional;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.entity.CarMaster;
import com.example.repo.CarMasterRepository;

@Component
@Service
@Qualifier("myImplementation")
public class CarMasterManagerImpl implements CarMasterManager
{

	@Autowired
	CarMasterRepository repository;

	@Override
	public List<CarMaster> getCarMaster() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void updatecar(CarMaster carMaster, int cid) {
		System.out.println("inside update method of service layer");
		repository.updatecar(carMaster.getCardtl(),carMaster.getImages(),carMaster.getisavailable(),cid);
	}
	
	@Override
	public void update(CarMaster carMaster, int cid) {
		System.out.println("inside update method of service layer");
		repository.update(cid);
	}
	
	public Optional<CarMaster> getCars(int id){
		return repository.findById(id);
	}
//	@Override
//	public void update(CarMaster carMaster, int cid) {
//		// TODO Auto-generated method stub
//		System.out.println("inside update method of service layer");
//		repository.update(carMaster.getCardtl(),carMaster.getisavailable(),carMaster.getimages(),cid);
//		
	
	
}
