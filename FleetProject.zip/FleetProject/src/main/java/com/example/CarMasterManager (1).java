package com.example.carmaster;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.CarTypes;

@Service
public interface CarMasterManager
{
	List<CarMaster> getCarMaster(); //get all data
	Optional<CarMaster> getCars(int id);
	void updatecar(CarMaster carMaster,int cid); //update the data
	void update(CarMaster carMaster,int cid);
}


