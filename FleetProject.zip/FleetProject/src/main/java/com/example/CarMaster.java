package com.example.carmaster;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="carmaster")
public class CarMaster
{
	private int carid;
	private String cardtl;
	private String isavailable;
	private String images;
//	private int cid;
//	private CarMaster<BookingHeaderTable> CarMasters;
	
	public String getIsavailable() {
		return isavailable;
	}

	public void setIsavailable(String isavailable) {
		this.isavailable = isavailable;
	}

	public String getImages() {
		return images;
	}

	public void setImages(String images) {
		this.images = images;
	}

	public CarMaster()
	{
		
	}

	public CarMaster(int carid, String cardtl,String images, String isavailable)
	{
		super();
		this.images=images;
		this.carid = carid;
		this.cardtl = cardtl;
		this.isavailable = isavailable;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getCarid() {
		return carid;
	}

	public void setCarid(int carid) {
		this.carid = carid;
	}

	public String getCardtl() {
		return cardtl;
	}

	public void setCardtl(String cardtl) {
		this.cardtl = cardtl;
	}
	
//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "cid", referencedColumnName="carid")
//	public CarMaster<CarMaster> getCarId() {
//	return this.CarMaster;
//	}
//	
	@Override
	public String toString() {
		return "Car_Master [carid=" + carid + ", cardtl=" + cardtl + ",isavailable=" + isavailable + "]";
	}
}
