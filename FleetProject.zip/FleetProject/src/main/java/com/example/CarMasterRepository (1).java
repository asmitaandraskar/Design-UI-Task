package com.example.carmaster;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
@Transactional
public interface CarMasterRepository extends JpaRepository<CarMaster,Integer>
{

//	@Modifying
//	@Query("update CarMaster c set c.isavailable = :isavailable where c.carid = :id")
//	void update(@Param("isavailable") int isavailable,@Param("id")int id);
	
	@Modifying
	@Query("update CarMaster c set c.images = :images,c.cardtl = :cardtl,c.isavailable = :isavailable where c.carid = :id")
	void updatecar(@Param("cardtl") String name,@Param("isavailable") String isavailable,@Param("images") String images,@Param("id")int id);
	
	@Modifying
	@Query("update CarMaster c set c.isavailable=(case when isavailable='Yes' then 'No' when isavailable='No' then 'Yes' end) where carid=:id")
	void update(@Param("id")int id);
	
}
